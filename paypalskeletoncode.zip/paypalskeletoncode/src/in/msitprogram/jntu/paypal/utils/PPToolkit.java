/**
 * 
 */
package in.msitprogram.jntu.paypal.utils;
/**
 * @author pg
 *
 */
public class PPToolkit {

	public static String generateActivationCode() 
	{
		
	    return "a23b45";
	}

	public static void sendActivationCode(String phone) 
	{
				
	}

}
