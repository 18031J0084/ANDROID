package in.msitprogram.jntu.paypal.persistance;
import java.io.*;
import java.util.Vector;

import in.msitprogram.jntu.paypal.accounts.PPAccount;

public class DataStore
{

	public static PPAccount lookupAccount(String email) throws IOException, ClassNotFoundException 
	{
		PPAccount account = null; //initialize it after reading from file
		// write code to open the files, read
		File file=new File("Paypal.txt");
		if(file.exists())
		{
		FileInputStream fin=new FileInputStream(file);
		ObjectInputStream oin=new ObjectInputStream(fin);  
		Vector<PPAccount> v=(Vector<PPAccount>)oin.readObject();
		 
				for(int i=1;i<v.size();i++)
				{
					account=v.get(i);
					if(account.getEmail().equals(email))
					{
						return  account;
					}
				}
		}
		
		return null;
	}
	public static void writeAccount(PPAccount account) throws Exception
	{
		PPAccount account1=null;
		File file=new File("Paypal.txt");
		Vector<PPAccount> v=new  Vector<PPAccount>();
		if(file.exists())
		{
		FileInputStream fi=new FileInputStream(file);
		ObjectInputStream oin=new ObjectInputStream(fi);
		DataInputStream di=new DataInputStream(fi);
		v=(Vector<PPAccount>)oin.readObject();
		 //v=(Vector<String>)oi.readObject();
		
			for(int i=0;i<v.size();i++)
			{
				account1=v.get(i);
		
		     if(account1.getEmail().equals(account.getEmail()))
			{
				v.remove(account1);
				break;
			}
		}
		
		FileOutputStream fout=new FileOutputStream(file);
		ObjectOutputStream ob=new ObjectOutputStream(fout);
		v.addElement(account);
		ob.writeObject(v);
		}
		else
		{
			FileOutputStream fout1=new FileOutputStream(file);
			ObjectOutputStream ob1=new ObjectOutputStream(fout1);
			v.addElement(account);
			ob1.writeObject(v);
		}
	}
}
	       
	      

	
	


