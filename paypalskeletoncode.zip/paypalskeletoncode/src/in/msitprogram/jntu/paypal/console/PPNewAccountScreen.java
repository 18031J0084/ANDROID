package in.msitprogram.jntu.paypal.console;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.Profile;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

public class PPNewAccountScreen {
	Profile profile;
	PPAccount account;
	String email;
	//Scanner scan;
	Scanner sc = new Scanner(System.in);
	public PPNewAccountScreen(String email) {
		profile = new Profile();	
		this.email = email;
	}

	public void show() throws Exception {
		
			//PPAccount account = DataStore.lookupAccount(email);
		
			if(account==null)
			{
			profile=createProfile();
			System.out.println("create new account");
			System.out.println("1.Business\n2.Student\n3.Personal");
			//Scanner sc = new Scanner(System.in);
			int ch = sc .nextInt();
			switch(ch)
			{
			case 1: 
				createBusinessAccount();
				break;
			case 2:
				createStudentAccount();
				show();
				break;
			case 3:
				createPersonalAccount();
				break;
				
			}	
		}
			else {
				System.out.println("email-id already exists");
			}
		}
		//check if the account with the given email address exists 
		
		//if not create the user profile
		
		//show the account types
		
		//based on the given account type selected create the account object
	

	private Profile createProfile() {
		// use this for creating the profile
		Scanner sc = new Scanner(System.in);
		Profile p = new Profile();
		System.out.println("enter your name: ");
		p.setName(sc.next());
		p.getName();
		System.out.println("enter your address: ");
		p.setAddress(sc.next());
		p.getAddress();
		System.out.println("enter your phone number: ");
		p.setPhone(sc.nextDouble());
		p.getPhone();
		return profile;
	}

	private void createBusinessAccount() throws IOException
	{
		//use this for creating the business account
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Business name:");
		String bname=sc.nextLine();
		System.out.println("Enter pan number:");
		int pan=sc.nextInt();
		
	}

	private void createStudentAccount() throws Exception
	{
		//use this for creating the student account 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter date of birth:");
		String dob=sc.nextLine();
		System.out.println("Enter Parent email id:");
		String p=sc.nextLine();
		completeAccountCreation();
	}
	/*
	 * this method create the personal account, saves it to the file system
	 * and redirects the users to the next screen
	 */
	private void createPersonalAccount() throws Exception {
		//use this for creating the personal account
		account = new PPAccount(profile,email);
		account.setAccountBal(30000);
		account.setActivated(false);
		completeAccountCreation();		
		
	}
	
	private void completeAccountCreation() throws Exception{
		//generate activation code and set it to account
		
		//send activation code to the phone
		
		//ask & redirect the user to the activation screen or the main menu
		Scanner sc = new Scanner(System.in);
		String link = PPToolkit.generateActivationCode();
		account.setActivationCode(link);
		DataStore.writeAccount(account);
		System.out.println("1. Activation code\n2. Main menu");
		int ch = sc.nextInt();
		switch(ch)
		{
		case 1:
			PPAccountActivationScreen ppas = new PPAccountActivationScreen();
			ppas.show();
			break;
		case 2:
			MainMenu.show();
			break;
		}
	}

}
