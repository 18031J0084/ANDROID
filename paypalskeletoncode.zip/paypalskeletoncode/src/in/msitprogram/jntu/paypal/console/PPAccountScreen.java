package in.msitprogram.jntu.paypal.console;

import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.persistance.DataStore;

public class PPAccountScreen {
	PPAccount account;
	Scanner scan;
	
	public PPAccountScreen(String email) throws Exception {
		scan = new Scanner(System.in);
		account = DataStore.lookupAccount(email);
	}

	public void show() throws Exception {
		if(account.isActivated())
		{
			
			System.out.println("account is activated");
			System.out.println(account);
			System.out.println("1. Deposit\n2. Withdraw\n3. requestMoney\n4. sendMoney");
			int ch = scan.nextInt();
			switch(ch)
			{
			case 1:
				addFunds();
				//DataStore.writeAccount(account);
				MainMenu.show();
				break;
			case 2:
				withdrawFunds();
				//DataStore.writeAccount(account);
				MainMenu.show();
				break;
			case 3:
				requestMoney();
				
				break;
			case 4:
				sendMoney();	
				break;		
			default:
				show();
			}
		}
		String email = null;
		//check if account is active
		/*if(	account == DataStore.lookupAccount(email))
		{
			System.out.println("Account already exist try with another account");
		}
		else{
			String newemail = null;
			PPNewAccountScreen ppn = new PPNewAccountScreen(newemail);
		}*/
		//if active
	
			// print the account summary
			System.out.println(account);
		 
			// print menu and accept menu options
			// for all the paypal account operations
		
		}	
	
	private void withdrawFunds() throws Exception {
		
		scan=new Scanner(System.in);
		System.out.println("enter amount you want to withdraw");
		double debit=scan.nextDouble();
		double balance=account.getAccountBal();

		if(balance>debit)
		{
			balance = balance-debit;
		}
		else
		{
			System.out.println("insufficient amount");
		}
		System.out.println("amount "+debit+" withdrawn from your account");
		//use the account object as needed for withdraw funds
		DataStore.writeAccount(account);
		System.out.println("your balance "+balance);
		
	}

	private void requestMoney() throws Exception {
		// 	implement the request money user interface here
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter email of requestor");
		String email=sc.next();
		System.out.println("amount you want ");
		float req=sc.nextFloat();
		System.out.println("request sent for "+req+" rupees to "+email );
	}
	private void sendMoney() {
		// implement the send money user interface here
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter email of sender ");
		String email=sc.next(); 
		System.out.println("amount you want to send ");
		float send=sc.nextFloat();
		if(account.getAccountBal()>=send)
		{
		System.out.println("amount sent to "+email+" is "+send);
		System.out.println("your balance "+(account.getAccountBal()-send));
		}
		else {
			System.out.println("you cannot send money. Insufficient balance");
		}
	}

	private void addFunds() throws Exception {
		// implement the add funds user interface here	
		//use the account object as needed for add funds
		scan=new Scanner(System.in);
		System.out.println("enter amount you want to add ");
		double credit=scan.nextDouble();
		double balance=account.getAccountBal();
		balance=balance+credit;
		//account.setAccountBal(account.getAccountBal()+credit);
		DataStore.writeAccount(account);
		System.out.println("amount "+credit+" added to your account");
		System.out.println("balance is "+balance);
	}

}