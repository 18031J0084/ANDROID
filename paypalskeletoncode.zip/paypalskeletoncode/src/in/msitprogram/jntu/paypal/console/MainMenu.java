
package in.msitprogram.jntu.paypal.console;

import java.util.*;

public class MainMenu 
{	
	public static void show() throws Exception
	{
		System.out.println("-----------------");
		System.out.println("Welcome to PayPal");
		System.out.println("-----------------");
		int ch;
		System.out.println("1. Sign-in with e-mail\n2. create new PayPal account");
		Scanner sc = new Scanner(System.in);
		ch = sc.nextInt();
		switch(ch)
		{
			case 1:	
				System.out.println("enter your email address:");
				String email = sc.next();
				PPAccountScreen ppa = new PPAccountScreen(email);
				ppa.show();
				break;
			case 2:
				System.out.println("New Account");
				System.out.println("enter email address:");
				String email1 = sc.next();
				PPNewAccountScreen ppn = new PPNewAccountScreen(email1);
				ppn.show();
				break;		
		}	
	}
}
