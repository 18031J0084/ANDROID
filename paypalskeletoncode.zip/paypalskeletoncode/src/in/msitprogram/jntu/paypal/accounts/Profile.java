package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;

public class Profile implements Serializable{
	
	private String name;
	private String address;
	private String phone;
	
	public void setName(String name)
	{

	}
	public String getName()
	{
		return name;
	}
	public void setAddress(String address)
	{

	}
	public String getAddress()
	{
		return address;
	}
	public void setPhone(double phone)
	{
		
	}
	public String getPhone()
	{
		return phone;
	}
	
	
}
