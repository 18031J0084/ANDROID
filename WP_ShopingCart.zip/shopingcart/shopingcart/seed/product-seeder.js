var Product = require('../models/product');

var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/shopping', {useNewUrlParser: true});


var products = [
    new Product({
        imagePath: 'https://rukminim1.flixcart.com/image/832/832/josxlzk0/mobile/g/p/z/mi-redmi-note-6-pro-mzb6876in-original-imafb6ggkruc4cxp.jpeg?q=70',
        title: 'Redmi Note5 Pro',
        description: 'A 20 MP + 2 MP dual front camera, a long-lasting battery and 15.9 cm (6.26-inch) screen - there is so much to love about the Redmi Note 6 Pro.supported by immense battery backup.',
        price: 15000
    }), 
    new Product({
        imagePath: 'https://images-na.ssl-images-amazon.com/images/I/61nzw1i2taL._SL1500_.jpg',
        title: 'Samsung M20',
        description: 'The Samsung Galaxy M20 64GB offers a host of features in an extremely affordable budget. The bezel-less wide display is one of the key features. The performance is also good and is supported by immense battery backup.',
        price: 13000
    }),
    new Product({
        imagePath: 'https://n1.sdlcdn.com/imgs/h/z/a/LALPAL-MAGNETIC-BLACK-GOLD-BLUETOOTH-SDL253563397-1-ba55e.jpeg',
        title: 'Philips Earphones',
        description: 'Designed to entertain, built to last, the Philips SHE1505 In The Ear Headphone with Mic is sure to be your best buddy in solitude. Its high-quality, lightweight construction allows you to carry it everywhere.',
        price: 550
    }),
    new Product({
        imagePath: 'https://images-na.ssl-images-amazon.com/images/I/61HWikiDHFL._SL1036_.jpg',
        title: 'ASUS Laptop',
        description: 'Processor : 2.3 GHz Intel Core i5-8300H (8M Cache, up to 3.9 GHz) 8th Gen processor Display : 15.6-inch (16:9) LED-backlit FHD (1920x1080) 60Hz Anti-Glare IPS-level Panel with 45% NTSC. Memory & Storage : 8GB DDR4 RAM.',
        price: 53000
    }),
    new Product({
        imagePath: 'https://images-na.ssl-images-amazon.com/images/I/61XUy0uBPXL._SL1280_.jpg',
        title: 'Fitbit Charge 3 Fitness Activity Tracker',
        description: 'Better measure calorie burn, understand resting heart rate and more with 24/7 heart rate tracking Battery lasts up to 7 days for continuous access to insights and inspiration, varies with use and other factors Use 15+ exercise modes.',
        price: 10000
    }),
    new Product({
        imagePath: 'https://images-na.ssl-images-amazon.com/images/I/81j-BxqtPEL._SL1500_.jpg',
        title: 'Laptop Bagpack',
        description: '2 Large compartments, 2 easy access front pocket with organizer section and 2 mesh side pocket outer fabric: durable PU coated water resistance polyester fabric Well cushioned laptop compartment for upto 15.6 inch laptop',
        price: 800
    }),
    ];

var done=0;

for(var i=0; i<products.length;i++)
{
    products[i].save(function(err, result)
    {
        done++;
        if(done===products.length)
        {
            exit();
        }
    });
}

function exit(){
mongoose.disconnect();
}