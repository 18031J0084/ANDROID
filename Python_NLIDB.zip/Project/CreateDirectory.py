import os
import requests
import re
from bs4 import BeautifulSoup

# create directory with ticker names

path = "C:/Users/manog/Desktop/Python/Project"

try:
    os.mkdir(path,0o755)
except OSError:
   print("Creation of dirctory %s failed" %path)
else:
   print("Successfully created.")

#create sub directory with ticker names and store html pages in particular ticker directory
file = open("tickers.txt",'r')
for x in file:
    for ticker in [x.split("::")]:
        root = "C:/Users/manog/Desktop/Python/Project/Tickers"
        path1 = os.path.join(root,ticker[0])
        try:
            os.mkdir(path1, 0o755)
        except OSError:
            print("Creation of dirctory %s failed" % path1)
        else:
            print("Successfully created.")

        url = "https://in.finance.yahoo.com/quote/"
        htmls = ['profile','financials','key-statistics']

        if ticker[0].__contains__("="):
            ticker1 = ticker[0].replace("=","%3D")

            #summary
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/"+ticker[0]+"/summary.html"
            summary = url+""+ticker1+"?p="+ticker1
            r = requests.get(summary,stream=True)
            with open(new_link,'wb') as f:
                f.write(r.content)
                f.close()

            #financial
            financial = url+""+ticker1+"/"+htmls[1]+"?p="+ticker1
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/financial.html"
            r = requests.get(financial, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #statistics
            statistics = url+""+ticker1+"/"+htmls[2]+"?p="+ticker1
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/statistics.html"
            r = requests.get(statistics, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #profile
            profile = url+""+ticker1+"/"+htmls[0]+"?p="+ticker1
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/profile.html"
            r = requests.get(profile, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

        elif ticker[0].__contains__("^"):
            ticker1 = ticker[0].replace("^","%5E")

            #summary
            summary = url+""+ticker1+"?p="+ticker1
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/summary.html"
            r = requests.get(summary, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #financial
            financial = url+""+ticker1+"/"+htmls[1]+"?p="+ticker1
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/financial.html"
            r = requests.get(financial, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #statistics
            statistics = url+""+ticker1+"/"+htmls[2]+"?p="+ticker1
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/statistics.html"
            r = requests.get(statistics, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #profile
            profile = url+""+ticker1+"/"+htmls[0]+"?p="+ticker1
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/profile.html"
            r = requests.get(profile, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()
        else:
            #summary
            summary = url+""+ticker[0]+"?p="+ticker[0]
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/summary.html"
            r = requests.get(summary, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #financial
            financial = url+""+ticker[0]+"/"+htmls[1]+"?p="+ticker[0]
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/financial.html"
            r = requests.get(financial, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #statistics
            statistics = url+""+ticker[0]+"/"+htmls[2]+"?p="+ticker[0]
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/statistics.html"
            r = requests.get(statistics, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

            #profile
            profile = url+""+ticker[0]+"/"+htmls[0]+"?p="+ticker[0]
            new_link = "C:/Users/manog/Desktop/Python/Project/Tickers/" + ticker[0] + "/profile.html"
            r = requests.get(profile, stream=True)
            with open(new_link, 'wb') as f:
                f.write(r.content)
                f.close()

print("Web Pages Saved Successfully")



