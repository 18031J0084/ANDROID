import psycopg2

conn = psycopg2.connect("user = postgres password = 18031j0068")
current = conn.cursor()


stats = "DROP TABLE IF EXISTS Statistics"
current.execute(stats)
pro = "DROP TABLE IF EXISTS Profile"
current.execute(pro)
fin = "DROP TABLE IF EXISTS Finances"
current.execute(fin)

statistics = current.execute("CREATE TABLE Statistics (SNo varchar,Ticker varchar PRIMARY KEY,Marketcap varchar ,Enterprise_Value varchar,Profit_Margin varchar,Return_On_Assets varchar,Gross_Profit varchar,Total_Cash varchar,Total_Debt varchar,Current_Ratio varchar,Operating_Cash_Flow varchar,Levered_Free_Cash_Flow varchar);")
print("Statistics created")
profile = current.execute("CREATE TABLE Profile (SNo varchar,Ticker varchar PRIMARY KEY,Name varchar,Address varchar,Phonenum varchar,Website varchar,Sector varchar,Industry varchar,Full_Time varchar,Bus_Summ varchar); ")
print("Profile created")
financial = current.execute("CREATE TABLE Finances (SNo varchar,Ticker varchar PRIMARY KEY,Total_Revenue varchar,Cost_of_Revenue varchar ,Income_Before_Tax varchar ,Net_Income varchar );")
print("Financial created")

conn.commit()
conn.close()
current.close()