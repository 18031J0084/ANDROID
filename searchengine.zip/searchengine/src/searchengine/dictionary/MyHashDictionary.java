package searchengine.dictionary;

public class MyHashDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>
{
	int size=10;
	Node<K,V> head;
	class Node<K,V>
	{
		K key;
		V value;
		Node next;
		Node(K key, V value)
		{
			this.key=key;
			this.value=value;
		}
	}
	Node<K,V> ar[]=new Node[size];
	@Override
	public String[] getKeys()
	{
		 int n=0;
		 String [] s= new String[5];
		 Node temp = head;
		 while(temp!=null)
		 {	 
			 s[n]=(String) temp.key;
			 n++;
			 temp=  temp.next;
		 }
		 return s;
	}
	@Override
	public V getValue(K str)
	{
		String v = null;
		Node temp=head;
		while(temp!=null)
		{
			if(temp.key==str)
			{
				v=(String) temp.value;
			}
			temp=temp.next;
		}
		return (V) v;
	}
	int hash(K key)
	{
		int in=Integer.parseInt((String) key)%size;
		System.out.println("index "+in);
		return in;
	}
	@Override
	public void insert(K key, V value) 
	{
		Node<K, V> n = new Node<K, V>(key, value);
		int ind=hash(key);
		Node temp=head;
		if(temp==null)
		{
			temp=n;
		}
		for(int i=0;i<ar.length;i++)
		{
			Node temp1=ar[i];
			while(temp1!=null)
			{
				temp1=temp1.next;
			}
			temp1=n;
			ar[ind]=temp1;
			System.out.println("arrr "+ar[ind].key);
			System.out.println("temp1  "+temp1.key);
		/*
		else
		{
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			temp=n;*/
		}
	}
	@Override
	public void remove(K key) 
	{
		
		
	}

}
