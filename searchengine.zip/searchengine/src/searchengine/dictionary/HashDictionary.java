package searchengine.dictionary;
import java.util.*;
public class HashDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{

	Hashtable<K,V> obj = new Hashtable<K,V>();
	@Override
	public String[] getKeys()
	{	
		 int n=0;
		 String [] s= new String[obj.size()];
		 Enumeration<K> e=obj.keys();
		 while(e.hasMoreElements())
		 {
			 s[n]= (String) e.nextElement();
			 n++;
		 }
		 
		 return s;
	}

	@Override
	public V getValue(K str) 
	{
		return obj.get(str);
	}
	@Override
	public void insert(K key, V value) 
	{
		obj.put(key, value);
	}

	@Override
	public void remove(K key)
	{
		obj.remove(key);
	}

}
