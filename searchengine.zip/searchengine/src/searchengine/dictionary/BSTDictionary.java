package searchengine.dictionary;


public class BSTDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>
{
	Node<K,V> root;
	String[] s;
	int size=0;
	int j;
	class Node<K,V>
	{
		Node<K,V> left,right;
		K key;
		V value;
		Node(K key,V value)
		{
			this.key=key;
			this.value=value;
		}
		
	}
	@Override
	public String[] getKeys() 
	{
		//System.out.println("in get  keys");
		j=0;
		s = new String[size];	
		disp(root);
		return s;
	}
	void disp(Node<K,V> root)
	{		
		//System.out.println("in disp"+root.key);
			if(root!=null)
			{
				
				disp(root.left);
				if(root.key!=null && root.value!=null)
				{
					//System.out.println("IN IF 1"+root.key);
					s[j++] = (String) root.key;
				}
				//System.out.println("**** "+root.key);
				disp(root.right);
			 }			
	}
	@Override 
	public V getValue(K str)
	{
		return get(str,root);
	}
	 public V get(K str,Node root)
	   {
		   
		   if(root!=null && str!=null)
		   {   
			   int cmp=str.compareTo((K) root.key);
			   //System.out.println("cmp: "+cmp);
			   if(cmp<0)
			   {
				  // System.out.println("cmp1::: "+cmp);
				    return get(str,root.left);
			   }
			   else if(cmp>0)
			   {
				   //System.out.println("cmp2===: "+cmp);
				   return get(str,root.right);
			   }
			   else {
				  // System.out.println("cmp3***: "+cmp);
				   return  (V) root.value;
			   }
		   }
		   
		return null;
	   
	   }	  
	@Override
	public void insert(K key, V value) 
	{
			root=inserting(root,key,value);
	} 
	Node<K,V> inserting(Node<K,V> root,K key,V value) 
    { 
		
        if (root==null) 
        { 
            root = new Node<K, V>(key,value);
            size++;
        }
        else
        {
        int cmp=key.compareTo( root.key);
        System.out.println("in cmp  "+cmp);
	    if(cmp<0)
		{
          return root.left = inserting(root.left,key,value); 
		}
      else if (cmp>0) 
      {
         return root.right=inserting(root.right,key,value);
      }
        }
		return root;
    }
	@Override
	public void remove(K key) 
	{
		root=del(root,key);
		
	}	
		Node del(Node root, K key) 
		{
			int cmp = key.compareTo((K) root.key);
	        if (root== null)
	        {
	        	return null;
	        }
	        else if(cmp < 0) {
	        	root.left  = del(root.left,  key);
	        }
	        else if (cmp > 0) {
	        	root.right = del(root.right, key);
	        }
	        else if (root.right == null) {
	        	return root.left;
	        }
	        else if (root.left  == null) {
	        	return root.right;
	        }
	     return root;
	 }
}