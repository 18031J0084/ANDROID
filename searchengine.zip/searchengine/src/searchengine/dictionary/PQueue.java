package searchengine.dictionary;

public interface PQueue <E extends Comparable<E>> 
{
	
	public void enqueue(E value);
	/*
	 * Inserts the element in the priority Queue
	 */
	
	public E dequeue();
	/*
	 * Deletes the Priority(first element) element from the Queue.
	 */
	
	public int size();
	/*
	 * Returns the number of elements of the Queue
	 */

	public boolean is_empty();
	/*
	 * Returns true if Queue is empty and false otherwise. 
	 */

	public E front();
	/*
	 * Returns the Priority(first element) element of the Queue 
	 */
	

}
