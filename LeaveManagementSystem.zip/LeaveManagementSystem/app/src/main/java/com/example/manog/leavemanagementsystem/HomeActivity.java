package com.example.manog.leavemanagementsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private Button logout;
    private ListView list;
    private Button Leave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        logout = (Button)findViewById(R.id.buttonLogout);
        Leave = (Button)findViewById(R.id.applyLeave);

        logout.setOnClickListener(this);
        Leave.setOnClickListener(this);
    }
    public void onClick(View v)

    {
        if(v == logout)
        {
            startActivity(new Intent(getApplicationContext(),LoginActivity.class));
        }
        else if(v == Leave )
        {
            Intent intent = new Intent(this,CalenderActivity.class);
            startActivity(intent);
        }

    }
}
