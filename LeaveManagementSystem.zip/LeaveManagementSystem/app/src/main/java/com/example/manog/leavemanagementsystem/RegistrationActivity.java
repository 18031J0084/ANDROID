package com.example.manog.leavemanagementsystem;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class RegistrationActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText name;
    private EditText rollnum;
    private EditText Email;
    private EditText phone;
    private EditText mentorName;
    private EditText password;
    private Button register;
    private TextView AlreadyExist;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();

        name = (EditText)findViewById(R.id.ETname);
        rollnum = (EditText)findViewById(R.id.ETrollno);
        Email = (EditText)findViewById(R.id.ETemail);
        phone = (EditText)findViewById(R.id.ETphone);
        mentorName = (EditText)findViewById(R.id.ETmentor);
        password = (EditText)findViewById(R.id.ETpwd);
        register = (Button)findViewById(R.id.btnReg);
        AlreadyExist = (TextView)findViewById(R.id.Already);

        register.setOnClickListener(this);
        AlreadyExist.setOnClickListener(this);

        }
    private void registerUser()
    {
        String emailId = Email.getText().toString().trim();
        String pass = password.getText().toString().trim();
        String roll = rollnum.getText().toString().trim();
        String Name = name.getText().toString().trim();
        String emailId1 = Email.getText().toString().trim();
        String mobile = phone.getText().toString().trim();
        String mentor = mentorName.getText().toString().trim();

        if(TextUtils.isEmpty(emailId))
        {
            Toast.makeText(this,"Enter e-mail id",Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(pass))
        {
            Toast.makeText(this,"Enter password",Toast.LENGTH_SHORT).show();
        }
        firebaseAuth.createUserWithEmailAndPassword(emailId, pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    //startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                    Toast.makeText(RegistrationActivity.this, "Authentication Success", Toast.LENGTH_SHORT).show();
                    return;
                } else

                {
                    Toast.makeText(RegistrationActivity.this, "Failed to Authenticate", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });


        UserInformation userInformation = new UserInformation(roll,Name,emailId1,mobile,mentor);

        FirebaseUser user = firebaseAuth.getCurrentUser();

        String sid = databaseReference.push().getKey();

        databaseReference.child(userInformation.rollNo).setValue(userInformation);

        Toast.makeText(this,"Information Saved..! ",Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onClick(View v) {

        if(v == register)
        {
            registerUser();
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        }

        if(v == AlreadyExist)
        {
            Intent intent = new Intent(RegistrationActivity.this,LoginActivity.class);
            startActivity(intent);
        }

    }
}