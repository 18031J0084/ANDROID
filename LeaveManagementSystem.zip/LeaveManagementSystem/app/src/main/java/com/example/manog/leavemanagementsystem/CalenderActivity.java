package com.example.manog.leavemanagementsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class CalenderActivity extends AppCompatActivity implements View.OnClickListener {

    private Button Submit;
    private RadioButton full;
    private RadioButton half;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender);

        Submit = (Button) findViewById(R.id.btnSubmit);
        full = (RadioButton)findViewById(R.id.RBFull);
        half = (RadioButton)findViewById(R.id.RBHalf);

        Submit.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

    }
}
