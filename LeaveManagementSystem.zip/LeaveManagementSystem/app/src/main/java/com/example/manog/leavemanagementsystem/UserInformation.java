package com.example.manog.leavemanagementsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class UserInformation {

    public String rollNo;
    public String name;
    public String email;
    public String mentor;
    public String mobile;

    public UserInformation(String rollNo, String name, String emailId1, String mobile, String mentor) {
        this.rollNo = rollNo;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.mentor = mentor;

    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMentor() {
        return mentor;
    }

    public void setMentor(String mentor) {
        this.mentor = mentor;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

}
